
import React from 'react';
import { Designer, UserStatus } from '../types';
import HeartIcon from './icons/HeartIcon';
import HeartFilledIcon from './icons/HeartFilledIcon';
import EyeIcon from './icons/EyeIcon';
import EyeSlashIcon from './icons/EyeSlashIcon';
import FlagIcon from './icons/FlagIcon';

interface DesignerCardProps {
  designer: Designer;
  onShortlistToggle: (id: string) => void;
}

const DesignerCard: React.FC<DesignerCardProps> = ({ designer, onShortlistToggle }) => {
  const getStatusColor = (status: UserStatus) => {
    switch (status) {
      case UserStatus.AVAILABLE:
        return 'bg-green-100 text-green-700';
      case UserStatus.BUSY:
        return 'bg-yellow-100 text-yellow-700';
      case UserStatus.ON_SABBATICAL:
        return 'bg-blue-100 text-blue-700';
      default:
        return 'bg-gray-100 text-gray-700';
    }
  };

  return (
    <div className="bg-emptycup-card-bg shadow-lg rounded-xl p-4 sm:p-6 mb-6 flex flex-col sm:flex-row items-start">
      <img 
        src={designer.imageUrl} 
        alt={designer.name} 
        className="w-24 h-24 sm:w-32 sm:h-32 rounded-full object-cover mr-0 mb-4 sm:mr-6 sm:mb-0 flex-shrink-0"
      />
      <div className="flex-grow">
        <div className="flex justify-between items-start">
          <div>
            <h2 className="text-xl sm:text-2xl font-bold text-emptycup-text-primary">{designer.name}</h2>
            <p className={`text-xs px-2 py-0.5 rounded-full inline-block my-1 ${getStatusColor(designer.status)}`}>
              {designer.status}
            </p>
          </div>
        </div>
        <p className="text-sm text-emptycup-text-secondary mt-1">{designer.role}</p>
        
        <div className="mt-3 space-y-1 text-sm text-emptycup-text-secondary">
          <p><span className="font-medium text-emptycup-text-primary">Projects:</span> {designer.projectsCompleted}</p>
          <p><span className="font-medium text-emptycup-text-primary">Experience:</span> {designer.experience}</p>
          <p><span className="font-medium text-emptycup-text-primary">Rate:</span> {designer.hourlyRate}</p>
          <p><span className="font-medium text-emptycup-text-primary">Location:</span> {designer.location}</p>
        </div>
      </div>
      <div className="flex flex-row sm:flex-col space-x-2 sm:space-x-0 sm:space-y-2 mt-4 sm:mt-0 sm:ml-4 flex-shrink-0">
        <button 
          title="Details"
          className="p-2 text-gray-500 hover:text-emptycup-primary transition-colors duration-150"
          onClick={() => alert(`Details for ${designer.name}`)}
        >
          <EyeIcon className="w-5 h-5" />
        </button>
        <button 
          title="Hide"
          className="p-2 text-gray-500 hover:text-red-500 transition-colors duration-150"
          onClick={() => alert(`Hide ${designer.name}`)}
        >
          <EyeSlashIcon className="w-5 h-5" />
        </button>
        <button 
          title={designer.isShortlisted ? "Remove from shortlist" : "Add to shortlist"}
          className={`p-2 transition-colors duration-150 ${designer.isShortlisted ? 'text-emptycup-primary' : 'text-gray-500 hover:text-emptycup-primary'}`}
          onClick={() => onShortlistToggle(designer.id)}
        >
          {designer.isShortlisted ? <HeartFilledIcon className="w-5 h-5" /> : <HeartIcon className="w-5 h-5" />}
        </button>
        <button 
          title="Report"
          className="p-2 text-gray-500 hover:text-orange-500 transition-colors duration-150"
          onClick={() => alert(`Report ${designer.name}`)}
        >
          <FlagIcon className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};

export default DesignerCard;
