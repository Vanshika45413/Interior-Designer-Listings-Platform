
import React from 'react';

interface IconProps {
  className?: string;
}

const StarFilledIcon: React.FC<IconProps> = ({ className }) => (
  <svg 
    xmlns="http://www.w3.org/2000/svg" 
    viewBox="0 0 24 24" 
    fill="currentColor" 
    className={className || "w-6 h-6"}
  >
    <path 
      fillRule="evenodd" 
      d="M10.788 3.21c.448-1.077 1.976-1.077 2.424 0l2.082 5.006a.42.42 0 0 0 .364.29l5.224.756c1.13.163 1.59 1.524.78 2.32l-3.776 3.664a.42.42 0 0 0-.122.47l.894 5.194c.198 1.121-.992 1.982-2.004 1.442L12.42 18.47a.42.42 0 0 0-.476 0l-4.66 2.454C6.27 21.358 5.08 20.508 5.28 19.386l.894-5.194a.42.42 0 0 0-.122-.47L2.274 10.08c-.81-.796-.35-2.157.78-2.32l5.224-.756a.42.42 0 0 0 .364-.29l2.082-5.006Z" 
      clipRule="evenodd" 
    />
  </svg>
);

export default StarFilledIcon;
