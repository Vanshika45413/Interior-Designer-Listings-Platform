
import React, { useState, useEffect, useCallback } from 'react';
import Header from './components/Header';
import DesignerCard from './components/DesignerCard';
import { Designer } from './types';
import { INITIAL_DESIGNERS } from './constants';

const App: React.FC = () => {
  const [designers, setDesigners] = useState<Designer[]>(INITIAL_DESIGNERS);
  const [showShortlistedOnly, setShowShortlistedOnly] = useState<boolean>(false);

  const handleShortlistToggle = useCallback((designerId: string) => {
    setDesigners(prevDesigners =>
      prevDesigners.map(designer =>
        designer.id === designerId
          ? { ...designer, isShortlisted: !designer.isShortlisted }
          : designer
      )
    );
  }, []);

  const handleShowShortlistedToggle = useCallback(() => {
    setShowShortlistedOnly(prev => !prev);
  }, []);

  const shortlistedCount = designers.filter(d => d.isShortlisted).length;
  const displayedDesigners = showShortlistedOnly 
    ? designers.filter(d => d.isShortlisted) 
    : designers;

  return (
    <div className="min-h-screen font-sans">
      <Header 
        showShortlistedOnly={showShortlistedOnly}
        onShowShortlistedToggle={handleShowShortlistedToggle}
        shortlistedCount={shortlistedCount}
      />
      <main className="max-w-4xl mx-auto p-4 sm:p-6">
        {displayedDesigners.length > 0 ? (
          <div className="space-y-6">
            {displayedDesigners.map(designer => (
              <DesignerCard 
                key={designer.id} 
                designer={designer} 
                onShortlistToggle={handleShortlistToggle} 
              />
            ))}
          </div>
        ) : (
          <div className="text-center py-12">
            <p className="text-xl text-emptycup-text-secondary">
              {showShortlistedOnly 
                ? "No designers shortlisted yet." 
                : "No designers available at the moment."}
            </p>
            {showShortlistedOnly && shortlistedCount === 0 && (
               <p className="text-sm text-gray-500 mt-2">Click the heart icon on a designer's card to shortlist them.</p>
            )}
          </div>
        )}
      </main>
      <footer className="text-center py-8 text-sm text-emptycup-text-secondary">
        <p>&copy; {new Date().getFullYear()} EmptyCup. All rights reserved.</p>
      </footer>
    </div>
  );
};

export default App;
