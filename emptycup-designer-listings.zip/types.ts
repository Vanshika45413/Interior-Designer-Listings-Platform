
export enum UserStatus {
  AVAILABLE = "Available",
  ON_SABBATICAL = "On Sabbatical",
  BUSY = "Busy",
}

export interface Designer {
  id: string;
  name: string;
  status: UserStatus;
  role: string; // e.g., "Interior Designer"
  projectsCompleted: string; // e.g., "120+ Projects"
  experience: string; // e.g., "5+ Years Experience"
  hourlyRate: string; // e.g., "$150/hr"
  location: string;
  imageUrl: string;
  isShortlisted: boolean;
}
